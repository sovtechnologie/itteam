import React, { useState, useEffect, useMemo } from "react";
import axios from "axios";
import "../../stylesheets/CompFilter.css";
import { useSearchParams } from "react-router-dom";
import JobCard from "./JobCard";


const BASE_URL = "https://qi0vvbzcmg.execute-api.ap-south-1.amazonaws.com";

const CompanyFilter = () => {
  const [currentPage, setCurrentPage] = useState(1);
  const [companies, setCompanies] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchParams] = useSearchParams();
  const [cities, setCities] = useState([]);
  const [loadingCities, setLoadingCities] = useState(false);

  const profilesPerPage = 12;

  const [filters, setFilters] = useState({
    workMode: [],
    experienceInStack: [],
    activeJoiners: [],
    state: "",
    location: "",
    currentPosition: "",
    expertTecStack: "",
    skillName: [],
    noticePeriod: [],
    salary: [0, 2000000],
  });

  useEffect(() => {
    if (searchParams.get("expertTecStack")) {
      setFilters((prevFilters) => ({
        ...prevFilters,
        expertTecStack: searchParams.get("expertTecStack"),
      }));
    }
    if (searchParams.get("experienceInStack")) {
      setFilters((prevFilters) => ({
        ...prevFilters,
        experienceInStack: searchParams.get("experienceInStack"),
      }));
    }
    if (searchParams.get("activeJoiners")) {
      setFilters((prevFilters) => ({
        ...prevFilters,
        activeJoiners: searchParams.get("activeJoiners"),
      }));
    }
    // if (searchParams.get("role")) {
    //     setRole(searchParams.get("role"));
    // }
  }, []);

  useEffect(() => {
    const fetchCompanies = async () => {
      setIsLoading(true);
      setError(null);

      try {
        let response;

        if (filters.location) {
          response = await axios.post(
            `${BASE_URL}/withoutLogin/companyFilterByLocation`,
            { city: filters.location }
          );
        } else {
          response = await axios.get(
            `${BASE_URL}/withOutLogin/getAllCompanyHomePage`
          );
        }

        if (response.data?.result) {
          setCompanies(response.data.result);
        } else {
          setCompanies([]);
          setError("No companies found");
        }
      } catch (err) {
        console.error(err);
        setError("Error fetching companies");
      } finally {
        setIsLoading(false);
      }
    };

    const timer = setTimeout(fetchCompanies, 500);
    return () => clearTimeout(timer);
  }, [filters.location]);

  useEffect(() => {
    const fetchCompany = async () => {
      try {
        const response = await axios.get(
          `${BASE_URL}/withOutLogin/getAllCompanyHomePage`
        );
        if (response.data?.result) {
          setCompanies(response.data.result);
        }
      } catch (error) {
        console.error("Error fetching company profile", error);
      }
    };
    fetchCompany();
  }, []);

  // Fetch cities when state changes
  useEffect(() => {
    const fetchCities = async () => {
      setLoadingCities(true);
      try {
        const response = await axios.get(
          `${BASE_URL}/withoutLogin/getCompanyActiveLocation`
        );
        if (response.data?.result) {
          console.log("cities", response.data.result);
          setCities(response?.data?.result);
        }
      } catch (error) {
        console.error("Error fetching cities:", error);
      } finally {
        setLoadingCities(false);
      }
    };

    fetchCities();
  }, []);

  const indexOfLastProfile = currentPage * profilesPerPage;
  const indexOfFirstProfile = indexOfLastProfile - profilesPerPage;
  const currentProfiles = companies.slice(
    indexOfFirstProfile,
    indexOfLastProfile
  );

  const totalPages = Math.ceil(companies.length / profilesPerPage);

  const paginationRange = useMemo(() => {
    const startPages = [1, 2, 3];
    const endPages = [totalPages - 2, totalPages - 1, totalPages];
    const pagination = [...startPages];

    if (totalPages > 6) {
      pagination.push("...");
      pagination.push(...endPages);
    } else {
      for (let i = 4; i <= totalPages; i++) pagination.push(i);
    }
    return pagination;
  }, [totalPages]);

  useEffect(() => {
    if (currentPage > totalPages) setCurrentPage(1);
  }, [totalPages, currentPage]);

  return (
    <>
      <div className="job-search-bar">
        <div className="search-fields">
          {" "}
          {/* 🆕 Wrap fields separately */}
          {/* <input
                        type="text"
                        className="search-input"
                        placeholder="Enter keyword / designation"
                        value={filters.expertTecStack}
                        onChange={handleStackChange}
                    />

                    <div className="divider" /> */}
          <div className="select-wrapper">
            <select
              className="search-select"
              value={filters.location || ""}
              onChange={(e) =>
                setFilters((f) => ({ ...f, location: e.target.value }))
              }
            >
              <option value="">Select City</option>
              {loadingCities ? (
                <option disabled>Loading...</option>
              ) : (
                cities.map((city, index) => (
                  <option key={city.location} value={city.location}>
                    {city.location}
                  </option>
                ))
              )}
            </select>
            <span className="dropdown-icon">▼</span>
          </div>
        </div>

        <button className="search-button">Search</button>
      </div>

      <div className="job-listing-container">
        {/* <div className="filter-section">
         
          <div className="filter-header">
            <h3>Filter</h3>
            <button className="reset-btn" onClick={handleResetFilters}>
              Reset
            </button>
          </div>

          <div className="filter-group">
            <h3 style={{ marginBottom: "10px" }}>Salary Range</h3>
            <SalaryFilterCard
              salaryRange={filters.salary}
              onSalaryChange={handleSalaryChange}
            />
          </div>

          <div className="filter-group">
            <h3 style={{ marginBottom: "10px" }}>Work mode</h3>
            {[
              { label: "W.F.O", value: 1 },
              { label: "Remote", value: 2 },
              { label: "Hybrid", value: 3 },
            ].map((mode) => (
              <div key={mode.value}>
                <label>
                  <input
                    type="checkbox"
                    checked={filters.workMode.includes(mode.value)}
                    onChange={() =>
                      handleCheckboxChange("workMode", mode.value)
                    }
                  />
                  {mode.label}
                </label>
              </div>
            ))}
          </div>

          <div className="filter-group">
            <h3 style={{ marginBottom: "10px" }}>Experience level</h3>

            {[
              { label: "Fresher", value: 1 },
              { label: "Junior", value: 2 },
              { label: "Mid-Level", value: 3 },
              { label: "Senior", value: 4 },
            ].map((exp) => (
              <div key={exp.label}>
                <label>
                  <input
                    type="checkbox"
                    checked={filters.experienceInStack.includes(exp.value)}
                    onChange={() =>
                      handleCheckboxChange("experienceInStack", exp.value)
                    }
                  />
                  {exp.label}
                </label>
              </div>
            ))}
          </div>

          <div className="filter-group">
            <h3 style={{ marginBottom: "10px" }}>Active Joiner</h3>
            {[
              { label: "Immediate", value: 1 },
              { label: "Within 7 Days", value: 2 },
              { label: "Within 15 Days", value: 3 },
              { label: "Within 30 Days", value: 4 },
              { label: "Within 45 Days", value: 5 },
            ].map((joiner) => (
              <label key={joiner.value}>
                <input
                  type="checkbox"
                  checked={filters.activeJoiners.includes(joiner.value)}
                  onChange={() =>
                    handleCheckboxChange("activeJoiners", joiner.value)
                  }
                />
                {joiner.label}
              </label>
            ))}
          </div>
        </div> */}

        <div className="job-cards-section">
          {/* Show message if no profiles found */}
          {!isLoading && companies.length === 0 && (
            <div className="no-data-message">
              {"No profiles found for the selected filters."}
            </div>
          )}

          {currentProfiles.map((job) => (
            <JobCard key={job._id} {...job} />
          ))}
        </div>
      </div>

      <div className="pagination">
        <button
          onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
          disabled={currentPage === 1}
        >
          &#8249; Prev
        </button>

        {paginationRange.map((page, index) =>
          page === "..." ? (
            <span key={index} className="dots">
              ...
            </span>
          ) : (
            <button
              key={page}
              onClick={() => setCurrentPage(page)}
              className={currentPage === page ? "active" : ""}
            >
              {page}
            </button>
          )
        )}

        <button
          onClick={() =>
            setCurrentPage((prev) => Math.min(prev + 1, totalPages))
          }
          disabled={currentPage === totalPages}
        >
          Next &#8250;
        </button>
      </div>
    </>
  );
};

export default CompanyFilter;
